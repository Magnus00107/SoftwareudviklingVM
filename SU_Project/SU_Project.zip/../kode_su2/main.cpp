#include <iostream>
#include <fstream>
#include <string>

int main() {
    std::ifstream file("values.txt");
    if (!file.is_open()) {
        std::cerr << "Error opening file!" << std::endl;
        return 1;
    }

    double value;

    while (file >> value) {
        std::cout << "Value: ";
    	std::cout << value << std::endl;

    }

    file.close();

    return 0;
}
